/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_utf8_test.h"

static char const*                        g_test_files[]=
{
"../test_files/combining-keycap.txt",
"../test_files/digraphs.txt",
"../test_files/grid-capital.txt",
"../test_files/grid-cyrillic-1.txt",
"../test_files/grid-cyrillic-2.txt",
"../test_files/grid-greek-1.txt",
"../test_files/grid-greek-2.txt",
"../test_files/grid-mixed-1.txt",
"../test_files/grid-mixed-2.txt",
"../test_files/grid-small.txt",
"../test_files/ipa-chart.txt",
"../test_files/ipa-english.txt",
"../test_files/luki2.txt",
"../test_files/lyrics-ipa.txt",
"../test_files/postscript-utf-8.txt",
"../test_files/quickbrown.txt",
"../test_files/revelation.txt",
"../test_files/rune-poem.txt",
"../test_files/TeX.txt",
"../test_files/UTF-8-demo.txt",
"../test_files/UTF-8-test.txt",
0
};

#include "../tabgen/string_char_to_bin.c"

extern void
abc_utf8c_read_test()
{
  char2binbuf_t                         l_buf;
  FILE*                                 l_fp;
  struct abc_utf8c                      l_utf8c;
  char const**                          l_path;
  size_t                                l_line;
  size_t                                l_pos;
  unsigned char const*                  l_octet;

  l_path= &g_test_files[0];

  do
  {

    if (0 == (*l_path))
    {
      break;
    }

    printf("file:%s\n", (*l_path));

    l_fp= fopen((*l_path), "rb");

    if (0 == l_fp)
    {
      perror("unable to open");
      l_path++;
      continue;
    }

    l_line= 1;
    l_pos= 0;
    memset(&l_utf8c, 0, sizeof(l_utf8c));

    do
    {

      l_pos+= l_utf8c.m_count;
      abc_utf8c_read(&l_utf8c, abc_utf8c_fread, l_fp);

      if (0 == l_utf8c.m_count)
      {
        break;
      }

      if (1 == l_utf8c.m_count)
      {
        if ('\n' == l_utf8c.m_block[0])
        {
          l_line++;
          l_pos= 0;
          continue;
        }
        if ('\r' == l_utf8c.m_block[0])
        {
          continue;
        }
      }

      if (l_utf8c.m_valid) 
      {
        continue;
      }

      printf("[%d:%d]:'%s'(%d)\n",
        l_line,
        l_pos,
        l_utf8c.m_block,
        l_utf8c.m_count);

      l_octet= (unsigned char*)&l_utf8c.m_block[0];

      do
      {

        if (0 == (*l_octet))
        {
          break;
        }

        memset(l_buf, 0, sizeof(l_buf));
        string_char_to_bin(l_buf, (*l_octet));

        printf(
          "   %03d:0x%02X:%s:'%c'\n",
          (*l_octet),
          (*l_octet),
          l_buf,
          (*l_octet));

        l_octet++;

      }while(1);

    }while(1);

    fclose(l_fp);
    l_path++;

  }while(1);

  return;
}
