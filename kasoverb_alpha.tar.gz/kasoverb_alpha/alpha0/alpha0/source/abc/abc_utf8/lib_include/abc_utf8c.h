/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap
*/
/*
  Copyright (c) 2007, 2010, 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#ifndef __abc_utf8c_h__

#include <stddef.h>
#include <stdio.h>

#define abc_utf8c_max_octets            6
#define abc_utf8c_sub_invalid_seq       0x3f

typedef void*                           abc_utf8c_handle_t;

typedef ptrdiff_t                       (*abc_utf8c_read_t)(
  abc_utf8c_handle_t const              i_handle,
  void*                                 o_block,
  size_t                                i_count);

struct abc_utf8c
{
  char                                  m_block[1+abc_utf8c_max_octets];
  size_t                                m_count;
  int                                   m_valid;
};

extern void
abc_utf8c_calc(
  size_t*const                          o_octets,
  int*                                  o_valid,
  char const                            i_octet);

extern ptrdiff_t
abc_utf8c_fread(
  abc_utf8c_handle_t const              i_handle,
  void*                                 o_block,
  size_t                                i_count);

extern void
abc_utf8c_parse(
  struct abc_utf8c*const                o_utf8c,
  void**                                io_block,
  size_t*const                          io_size);

extern int
abc_utf8c_read(
  struct abc_utf8c*const                o_utf8c,
  abc_utf8c_read_t const                i_read,
  abc_utf8c_handle_t const              i_handle);

#define __abc_utf8c_h__
#endif
