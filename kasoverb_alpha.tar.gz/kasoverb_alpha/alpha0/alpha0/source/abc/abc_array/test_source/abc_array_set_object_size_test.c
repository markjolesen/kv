/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_array_test.h"

#define SLOTS 255

extern void
abc_array_set_object_size_test()
{
  struct abc_array                      l_array;
  char*                                 l_char_ptr;
  int*                                  l_int_ptr;
  size_t                                l_slot;

  abc_array_assign(&l_array);

  abc_array_set_object_size(&l_array, 0);
  abc_array_set_count(&l_array, 1, 0);
  if (l_array.m_count || l_array.m_blob.m_size || l_array.m_blob.m_alloc)
  {
    printf("%s(%d): !0\n",  __FUNCTION__, __LINE__);
  }
  abc_array_set_object_size(&l_array, 1);
  abc_array_set_count(&l_array, 1, 0);
  abc_array_set_object_size(&l_array, 0);
  if (l_array.m_count)
  {
    printf("%s(%d): %d != 0\n",  __FUNCTION__, __LINE__, l_array.m_count);
  }

  abc_array_discharge(&l_array);
  abc_array_assign(&l_array);
  abc_array_are_fields_zero_test(&l_array, __FUNCTION__, __LINE__);
  abc_array_set_object_size(&l_array, sizeof(*l_int_ptr));
  abc_array_set_count(&l_array, SLOTS, 0);
  abc_array_as_ptr((char**)&l_int_ptr, &l_array);
  abc_array_zero_test(l_array.m_blob.m_block, l_array.m_blob.m_alloc, __FUNCTION__, __LINE__);

  l_slot= 0;
  do
  {
    if (SLOTS <= l_slot)
    {
      break;
    }
    *l_int_ptr++= l_slot++;
  }while(1);

  abc_array_set_object_size(&l_array, sizeof(*l_char_ptr));
  abc_array_as_ptr((char**)&l_char_ptr, &l_array);

  l_slot= 0;
  do
  {
    if (SLOTS <= l_slot)
    {
      break;
    }
    if ((*l_char_ptr) != (char)l_slot)
    {
      printf("%s(%d): [%d] 0x%X != 0x%X\n", __FUNCTION__, __LINE__, l_slot, l_slot, l_char_ptr[0]);
    }
    l_char_ptr++;
    l_slot++;
  }while(1);

  abc_array_set_object_size(&l_array, sizeof(*l_int_ptr));
  abc_array_as_ptr((char**)&l_int_ptr, &l_array);

  l_slot= 0;
  do
  {
    if (SLOTS <= l_slot)
    {
      break;
    }
    if ((*l_int_ptr) != (int)l_slot)
    {
      printf("%s(%d): [%d] 0x%X != 0x%X\n", __FUNCTION__, __LINE__, l_slot, l_slot, l_int_ptr[0]);
    }
    *l_int_ptr++= 0;
    l_slot++;
  }while(1);

  abc_array_zero_test(l_array.m_blob.m_block, l_array.m_blob.m_alloc, __FUNCTION__, __LINE__);
  abc_array_set_object_size(&l_array, 0);
  abc_array_as_ptr((char**)&l_char_ptr, &l_array);
  if (0 != l_char_ptr)
  {
    printf("%s(%d): 0 != %p\n", __FUNCTION__, __LINE__, l_char_ptr);
  }
  abc_array_get_count(&l_slot, &l_array);
  if (0 != l_slot)
  {
    printf("%s(%d): 0 != %d\n", __FUNCTION__, __LINE__, l_slot);
  }
  abc_array_set_count(&l_array, SLOTS, 0);
  abc_array_get_count(&l_slot, &l_array);
  if (0 != l_slot)
  {
    printf("%s(%d): 0 != %d\n", __FUNCTION__, __LINE__, l_slot);
  }
  abc_array_zero_test(l_array.m_blob.m_block, l_array.m_blob.m_alloc, __FUNCTION__, __LINE__);
  abc_array_discharge(&l_array);
  abc_array_are_fields_zero_test(&l_array, __FUNCTION__, __LINE__);

  return;
}
