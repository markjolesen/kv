#!/usr/bin/perl

use Getopt::Long;
use File::stat;
use Fcntl ':mode';
use File::Spec;

my $srcpath='./';
my $dstpath= './';
my $rc= 0;
my $vol='';
my $app='';
my $file='';

  Getopt::Long::GetOptions(
    "src=s" => \$srcpath,
    "dest=s" => \$dstpath,
    "help"=>\$help) or $rc=1;

  if ('' eq srcpath)
  {
    $srcpath= "./";
  }

  if ('' eq dstpath)
  {
    $dstpath= "./";
  }

  if ($rc || $help)
  {
    usage_print();
    exit(-1);
  }

  $dstpath.='/';

  ($vol,$app,$file) = File::Spec->splitpath($0);

  $app=$vol.$app.'/abc_pod2htm.pl';

  $rc= dir_scope($app, $srcpath, $dstpath);

  exit($rc);


sub usage_print
{
  print "usage:\n\t$0 [--src=source] [--dest=destination]\n";
}

sub commit_check
{
  my $src= shift(@_);
  my $dst= shift(@_);
  my $src_mtime= 0;
  my $dst_mtime= 0;

  $dst_mtime= (stat($dst))[8];
  if (not defined($dst_mtime))
  {
    return 1;
  }

  $src_mtime= (stat($src))[8];
  if (not defined($src_mtime))
  {
    return 1;
  }

return ($src_mtime - $dst_mtime);
}


sub dir_scope
{
  my $app= shift(@_);
  my $srcpath= shift(@_);
  my $dstpath= shift(@_);
  my $nfile= '';
  my $ent= '';
  my $fd= 0;
  my %stat= ();
  my @list=();
  my $index= '';
  my $ext= '';
  my $name= '';

  $rc= opendir($fd, $srcpath);

  if (0 == $rc)
  {
      print "$! -- unable to open ('$srcpath')\n";
      usage_print();
      exit(-1);
  }

  @list= readdir($fd);

  close($fd);

  for $ent (@list)
  {
    $nfile=$srcpath.'/'.$ent;
    $stat= stat($nfile);
    if (S_ISDIR($stat->mode))
    {
      if (('.' ne $ent) and ('..' ne $ent))
      {
        dir_scope($app, $nfile, $dstpath);
      }
    }
    elsif (S_ISREG($stat->mode))
    {
      $index= rindex($ent, '.'); 
      if (0 < $index)
      {
        $ext= substr($ent, $index);
        if ('.pod' eq $ext)
        {
          $name= substr($ent, 0, $index);
          $out= $dstpath.$name.'.htm';
          if (commit_check($nfile, $out))
          {
            # path to abc_pod2htm needs work
            $nfile=~ s/ /\\ /g;
            $out=~ s/ /\\ /g;
            $cmd= "$app --infile=$nfile --outfile=$out";
            system($cmd);
          }
        }
      }
    }
  } # for
}

__END__

vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler

