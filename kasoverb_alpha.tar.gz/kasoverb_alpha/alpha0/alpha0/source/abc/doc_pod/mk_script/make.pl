#!/usr/bin/perl

my @dirs=`find ../../ -name pod_source`;
my $cmd;
my $FH;
my $src;

for $src(@dirs)
{
  chomp($src);
  $cmd="./abc_podexp.pl --src=$src --dest=../html/";
  system($cmd);
}

open($FH, ">", "../html/index.htm") || die ("unable to create index\n");
print $FH "<ui>\n";
print $FH "<li><a href='abc_array.htm'>abc_array</a></li>\n";
print $FH "<li><a href='abc_blob.htm'>abc_blob</a></li>\n";
print $FH "<li><a href='abc_csv.htm'>abc_csv</a></li>\n";
print $FH "<li><a href='abc_fstring.htm'>abc_fstring</a></li>\n";
print $FH "<li><a href='abc_r7.htm'>abc_r7</a></li>\n";
print $FH "<li><a href='abc_r8.htm'>abc_r8</a></li>\n";
print $FH "<li><a href='abc_string.htm'>abc_string</a></li>\n";
print $FH "<li><a href='abc_utf8.htm'>abc_utf8</a></li>\n";
print $FH "</ui>\n";
close $FH;


__END__

vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
