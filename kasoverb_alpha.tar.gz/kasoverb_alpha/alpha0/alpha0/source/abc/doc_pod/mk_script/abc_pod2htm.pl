#!/usr/bin/perl
=pod

=begin COPYRIGHT

 Copyright (C) 2014 Mark J. Olesen

 This work is free. You can redistribute it and/or modify it under the
 terms of the Do What The Fuck You Want To Public License, Version 2,
 as published by Sam Hocevar.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO.

=end COPYRIGHT

=head1 NAME

abc_pod2htm - exports pod format to HTML

=head1 SYNOPSIS

Takes Perl POD input and exports to HTML. Output is sent to STDOUT.
If there are no arguments or an argument missing, STDIN and STDOUT 
will be used. 
Otherwise, it will open the file(s) listed on the command line.

=head1 NOTES

This is a hack to applications such as Perldoc or pod2html. At the time, there was
a problem using this utilties. The L (link) did not work. 

This module is incomplete. It is used to export the abc library POD documentation.
This documentation is simplistic (does not use all features of POD) and follows
a consistent format.

=cut

use Pod::Tree;
use Getopt::Long;

my %options= ();
my $tree= new Pod::Tree;
my $node;
my $infile='';
my $outfile='';
my $rc=0;
my $help=0;

  Getopt::Long::GetOptions(
    "infile:s" => \$infile,
    "outfile:s" => \$outfile,
    "help"=>\$help) or $rc=1;

  if ($rc || $help)
  {
    usage_print();
    exit(-1);
  }

  if (length($outfile))
  {
    open($OUTFH, ">", $outfile) or $rc=1;
    if ($rc)
    {
      print "$! -- unable to open $outfile\n";
      usage_print();
      exit(-1);
    }
  }
  else
  {
    $OUTFH= *STDOUT;
  }

  if (length($infile))
  {
    $tree->load_file($infile, $options);
  }
  else
  {
    $tree->load_fh(\*STDIN, $options);
  }

  $node= $tree->get_root();
  if ($node)
  {
    scope($node);
  }

  exit(0);

sub usage_print
{
  print "usage:\n\t$0 [--infile=podfile] [--outfile=htmfile]\n";
  print "\tif infile is not supplied, STDIN will be used\n";
  print "\tif outfile is not supplied, STDOUT will be used\n";
}


sub scope_iter
{
  my $node= shift(@_);
  my $children;
  my $child;

  $children= $node->get_children();
  for $child (@$children)
  {
    scope($child);
  }

}

sub scope_sequence
{
  my $node= shift(@_);
  my $children;
  my $child;
  my $command;
  my $what;
  my $text;
  my $char;
  my $link;

  while(1)
  {

    $what= $node->get_letter;

    if ('I' eq $what)
    {
      print $OUTFH "<i>";
      scope_iter($node);
      print $OUTFH "</i>";
    }

    if ('B' eq $what)
    {
      print $OUTFH "<b>";
      scope_iter($node);
      print $OUTFH "</b>";
      last;
    }

    if ('L' ne $what)
    {
      last;
    }

    $text= '';
    $children= $node->get_children();
    for $child (@$children)
    {
      $text.= $child->get_text();
    }

    $char= substr($text, 0, 1);

    if ('/' eq $char)
    {
      $text= substr($text, 1);
      $link= '#'.$text;
    }
    else
    {
      $link= $text.'.htm';
    }

    print $OUTFH "<a href='$link'>$text</a>";

  last;}

}

sub scope_command
{
  my $node= shift(@_);
  my $children;
  my $child;
  my $command;
  my $text;

#=pod
#=head1 Heading Text
#=head2 Heading Text
#=head3 Heading Text
#=head4 Heading Text
#=over indentlevel
#=item stuff
#=back
#=begin format
#=end format
#=for format text...
#=encoding type
#=cut

  $command = $node->get_command();
  $text= $node->get_text();
  $text=~ s/^\s+|\s+$//g;

  if ('head1' eq $command)
  {
    print $OUTFH "<h1><a name='$text'>$text</a></h1>\n";
  }
  elsif ('head2' eq $command)
  {
    print $OUTFH "<h2><a name='$text'>$text</a></h2>\n";
  }
  elsif ('head3' eq $command)
  {
    print $OUTFH "<h3><a name='$text'>$text</a></h3>\n";
  }
  elsif ('head4' eq $command)
  {
    print $OUTFH "<h4><a name='$text'>$text</a></h4>\n";
  }
}


sub scope
{
  my $node= shift(@_);
  my $children;
  my $child;
  my $text;
  my $command;

  while(1)
  {
    if ('root' eq $node->get_type())
    {
      # The node is the root of the tree.
      scope_iter($node);
      last;
    }
    if ('code' eq $node->get_type())
    {
      #  The node represents a paragraph that is not part of the POD.
      # A code node contains the text of a paragraph that is not part of the POD, for example, a paragraph that follows an =cut command.
      $text = $node->get_text;
      # ignore all code text?
#      if (-1 == index('__END___', $text))
#      {
        print $OUTFH "<code>$text</code>";
#      }
      last;
    }
    if ('verbatim' eq $node->get_type())
    {
      # The node represents a verbatim paragraph.
      # A verbatim node contains the text of a verbatim paragraph
      $text = $node->get_text;
      print $OUTFH "<pre>$text</pre>";
      last;
    }
    if ('ordinary' eq $node->get_type())
    {
      # The node represents an ordinary paragraph.
      # An ordinary node represents the text of an ordinary paragraph. The text is parsed into a list of text and sequence nodes; these nodes are the children of the ordinary node
      scope_iter($node);
      last;
    }
    if ('command' eq $node->get_type())
    {

      # The node represents an =command paragraph (but not an =over paragraph).
      # A command node represents an =command paragraph
      # The text of a command paragraph is parsed into a list of text and sequence nodes; these nodes are the children of the command node.
      scope_command($node);
      last;
    }
    if ('sequence' eq $node->get_type())

    {
      # The node represents an interior sequence.
      scope_sequence($node);
      last;
    }
    if ('target' eq $node->get_type())
    {
      # The node represents the target of a link (An L<> markup).
    }
    if ('text' eq $node->get_type())
    {
      # The node represents text that contains no interior sequences.
      $text= $node->get_text();
      print $OUTFH $text;
      last;
    }
    if ('list' eq $node->get_type())
    {
      # The node represents an =over list.
      print $OUTFH "<ui>";
      scope_iter($node);
      print $OUTFH "</ui>";
      last;
    }
    if ('item' eq $node->get_type())
    {
      # The node represents an item in an =over list.
      print $OUTFH "<li>";
      scope_iter($node);
      print $OUTFH "</li>";
      last;
    }
    if ('for' eq $node->get_type())
    {
      # The node represents a =for paragraph, or it represents the paragraphs between =begin/=end commands.
      last;
    }
  last;};
}

__END__

vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
