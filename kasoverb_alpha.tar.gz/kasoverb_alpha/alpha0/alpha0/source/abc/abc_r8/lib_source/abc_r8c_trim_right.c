/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2007, 2010, 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_r8.h"

#ifndef abc_r7_space
# define abc_r7_space                   0x20
#endif

extern void
abc_r8c_trim_right(
  void*const                            io_block,
  size_t const                          i_size)
{
  size_t                                l_count;
  size_t                                l_left;
  size_t                                l_size;
  char*                                 l_space;
  char*                                 l_src;

  do
  {

    if (0 == io_block)
    {
      break;
    }

    if (0 == i_size)
    {
      break;
    }

    if (0 == (*(char*)io_block))
    {
      memset(io_block, 0, i_size);
      break;
    }

    l_count= 0;
    l_left= i_size;
    l_size= 0;
    l_space= 0;
    l_src= (char*)io_block;

    do
    {

      if (0 == l_left)
      {
        break;
      }

      if (0 == (*l_src))
      {
        memset(l_src, 0, l_left);
        break;
      }

      if ((abc_r7_space != (*l_src)) && (abc_r7_ht != (*l_src)))
      {
        l_space= 0;
      }
      else if (0 == l_space)
      {
        l_space= l_src;
        l_count= l_left;
      }

      l_left--;
      l_size++;
      l_src++;

    }while(1);

    if (0 == l_space || 0 == l_count)
    {
      break;
    }

    memset(l_space, 0, l_count);

  }while(0);

  return;
}
