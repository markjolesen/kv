verbs_introduction.doc file submitted to project by Adolfo Caso of Branden Books on 12/07/2010.  Please note, the document is copyright 2005 Branden Books. 

The document is an introduction to the original (2005) Kaso Verb Conjugation 
System.  The author mentioned the title should be 
``Understanding English and Italian Verbs.''
