#!/bin/bash
# vim:noexpandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap
#
#  Copyright (c) 2010, 2015 Dante University Foundation and Contributors
#  
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are met:
#  
#     1. Redistributions of source code must retain the above copyright notice,
#        this list of conditions and the following disclaimer.
#  
#     2. Redistributions in binary form must reproduce the above copyright
#        notice, this list of conditions and the following disclaimer in the
#        documentation and/or other materials provided with the distribution.
#  
#  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
#  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
#  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
#  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
#  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
#  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
#  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
#  POSSIBILITY OF SUCH DAMAGE.
#  
#  The views and conclusions contained in the software and documentation are
#  those of the authors and should not be interpreted as representing official
#  policies, either expressed or implied, of Dante University Foundation.
#  
#  Dante University Foundation
#  P.O. Box 812158
#  Wellesley, MA 02482
#  USA
#  www.danteuniversity.org

# This is a temporary build script that uses GNU make (gmake) for GNU/Linux
# 
# The default build includes debug data. ``strip'' can be used to remove it.
# 
# The fast light toolkit (FLTK) 1.3.x series needs to be downloaded, configured,
# and compiled for static libraries. FLTK can be obtained through fltk.org.
# 
# ENVIRONMENT
# FLTK 
# path to top level fast light tool kit directory
# default path is <scriptdir>/../vendor/fltk
#
# STATUS
# use at your own risk

# code snippet to get path of script retrieved 
# from http://hintsforums.macworld.com/archive/index.php/t-73839.html
# on 12/9/2010
script="$(cd "${0%/*}" 2>/dev/null; echo "$PWD"/"${0##*/}")"
script_path=`dirname $script`

cd $script_path

gmake=`which gmake || which make`

if [ -z "$gmake" ]; then
	echo "unable to find make"
	exit -1
fi

if [ -z "$dir_top_fltk" ]; then
	if [ -n "$FLTK" ]; then
		dir_top_fltk=$FLTK
	else
		dir_top_fltk=$script_path/../vendor/fltk
	fi
fi

if [ ! -e $dir_top_fltk/configure ]; then
	echo "FLTK top directory not set or not found: '$dir_top_fltk'"
	exit -1
fi

if [ -f $dir_top_fltk/makeinclude ]; then
	lib_all_fltk_x=`grep ^LDLIBS $dir_top_fltk/makeinclude | cut -d= -f2`
else
	lib_all_fltk_x="-lXext -lXft -lfontconfig -lXinerama -lpthread -ldl -lm  -lX11" 
fi

export dir_top_fltk
export lib_all_fltk_x
export lib_all_fltk="-L${dir_top_fltk}/lib -lfltk -lfltk_images ${lib_all_fltk_x}"
export LIBCOMMAND=ar
export RANLIB=ranlib

make -C -f abc/makfile
export CC=g++
${gmake} -C kvc/kvc_rec/lib_gmake && \
${gmake} -C kvc/kvc_db/lib_gmake && \
${gmake} -C kvc/kvc_dict/lib_gmake && \
${gmake} -C kvc/kvc_icon/lib_gmake && \
${gmake} -C kvc/kvc_main/bin_gmake 
