/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_utf8.h"

extern void
abc_utf8s_filter(
  char*                                 io_str,
  abc_utf8s_filter_t const              i_filter)
{
  enum abc_utf8s_filter_action          l_action;
  abc_utf8s_filter_t                    l_filter;
  char*                                 l_object_dst;
  char*                                 l_object_src;
  char*                                 l_src;
  char                                  l_template;
  struct abc_utf8c                      l_utf8c;

  do
  {

    if (0 == io_str) 
    {
      break;
    }

    l_filter= ((i_filter) ?  i_filter : abc_utf8s_filter_default);
    l_object_dst= io_str;
    l_object_src= io_str;

    do
    {

      if (0 == (*l_object_src))
      {
        break;
      }

      l_src= l_object_src;
      abc_utf8s_parse(&l_utf8c, &l_object_src);
      (*l_filter)(&l_action, &l_template, &l_utf8c);

      memset(l_src, 0, l_utf8c.m_count);

      if (abc_utf8s_filter_action_terminate == l_action)
      {
        break;
      }

      if (abc_utf8s_filter_action_leave == l_action)
      {
        memcpy(l_object_dst, &l_utf8c.m_block[0], l_utf8c.m_count);
        l_object_dst+= l_utf8c.m_count;
      }
      else if (abc_utf8s_filter_action_remove != l_action)
      {
        if (0 == l_template)
        {
          break;
        }
        memset(l_object_dst, l_template, l_utf8c.m_count);
        l_object_dst+= l_utf8c.m_count;
      }

    }while(1);

  }while(0);

  return;
}
