/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap
*/
/*
  Copyright (c) 2007, 2010, 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_utf8.h"

extern int
abc_utf8c_read(
  struct abc_utf8c*const                o_utf8c,
  abc_utf8c_read_t const                i_read,
  abc_utf8c_handle_t const              i_handle)
{
  unsigned char                         l_bits;
  int                                   l_exit;
  unsigned char const*                  l_octet;
  size_t                                l_octets;
  ptrdiff_t                             l_rc;
  int                                   l_valid;
  
  l_exit= 0;
  l_valid= 0;

  do
  {

    if (0 == o_utf8c)
    {
        break;
    }

    memset(o_utf8c, 0, sizeof(*o_utf8c));

    if (0 == i_read)
    {
      break;
    }

    l_rc= (*i_read)(i_handle, &(*o_utf8c).m_block[0], 1);
  
    if (1 != l_rc)
    {
      if (0 > l_rc)
      {
        l_exit= -1;
      }
      break;
    }
    
    (*o_utf8c).m_count= 1;
    abc_utf8c_calc(&l_octets, &l_valid, (*o_utf8c).m_block[0]);

    if (1 == l_octets)
    {
      break;
    }

    l_octets--;
    l_rc= (*i_read)(i_handle, &(*o_utf8c).m_block[1], l_octets);

    if (0 > l_rc)
    {
      l_exit= -1;
      break;
    }

    (*o_utf8c).m_count+= (size_t)l_rc;

    if (l_rc != (ptrdiff_t)l_octets)
    {
      break;
    }

    if (0 == l_valid)
    {
      break;
    }

    l_octet= (unsigned char*)&(*o_utf8c).m_block[1];

    do
    {

      if (0 == (*l_octet))
      {
        break;
      }

      l_bits= ((*l_octet) >> 6);

      if (0x2 /* 10b */ != l_bits)
      {
        l_valid= 0;
        break;
      }

      l_octet++;

    }while(1);

  }while(0);

  if (o_utf8c)
  {
    (*o_utf8c).m_valid= l_valid;
  }

  return l_exit;
}
