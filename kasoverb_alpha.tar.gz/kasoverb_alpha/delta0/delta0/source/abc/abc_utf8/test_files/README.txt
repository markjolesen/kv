The files in this directory are used for testing abc_utf8 library functionality.
REGRESSION_FILE.txt is used to compare expected results.

The files below were obtained from Dr Markus Kuhn http site.

They can be downloaded from 

   http://www.cl.cam.ac.uk/~mgk25/ucs/examples/

see also COPYING.txt

combining-keycap.txt
digraphs.txt
grid-capital.txt
grid-cyrillic-1.txt
grid-cyrillic-2.txt
grid-greek-1.txt
grid-greek-2.txt
grid-mixed-1.txt
grid-mixed-2.txt
grid-small.txt
ipa-chart.txt
ipa-english.txt
luki2.txt
lyrics-ipa.txt
postscript-utf-8.txt
quickbrown.txt
revelation.txt
rune-poem.txt
TeX.txt
UTF-8-demo.txt
UTF-8-test.txt
