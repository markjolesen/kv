./abc_utf8_test > ./regress.txt
diff -t ../test_files/REGRESSION_FILE.txt ./regress.txt
