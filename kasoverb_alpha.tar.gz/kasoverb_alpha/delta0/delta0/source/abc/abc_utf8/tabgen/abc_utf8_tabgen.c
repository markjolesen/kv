/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#include "abc_utf8c_calc.c"
#include "string_char_to_bin.c"

extern int
main()
{
  char2binbuf_t                         l_buf;
  int                                   l_exit;
  size_t                                l_octets;
  int                                   l_valid;
  unsigned char                         l_octet;

  l_exit= 0;
  l_octet= 0;

  printf("static struct abc_utf8c_table\n");
  printf("{\n");
  printf("  size_t                                m_size;\n");
  printf("  int                                   m_legal;\n");
  printf("}                                       l_table[256]=\n");
  printf("{\n");

  do
  {

    l_octets= 0;
    abc_utf8c_calc(&l_octets, &l_valid, l_octet);

    printf(
      "  {%d,%d}%s",
      l_octets,
      (l_valid ? 1 : 0),
      ((255 > l_octet) ? "," : " "));

    memset(l_buf, 0, sizeof(l_buf));
    string_char_to_bin(l_buf, l_octet);

    printf(
      " /*%03d:0x%02X:%s:size=%d:valid=%s*/\n", 
      l_octet,
      l_octet,
      l_buf,
      l_octets,
      (l_valid) ? "y" : "n");

    if (255 == l_octet)
    {
      break;
    }

    l_octet++;

  }while(1);

  printf("};\n");

  return l_exit;
}
