/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/

static void
abc_utf8c_calc(
  size_t*const                          o_octets,
  int*                                  o_valid,
  unsigned char const                   i_octet)
{
  unsigned char                         l_bits;
  int                                   l_valid;

  l_valid= 0;

  do
  {

    if (0 == o_octets)
    {
      break;
    }

    l_valid= 1;
    (*o_octets)= 0;

    l_bits= (i_octet >> 7);

    if (0 == /* 0b */ l_bits)
    {
      (*o_octets)= 1;
      break;
    }

    l_bits= (i_octet >> 5);

    if (0x6 /* 110b */ == l_bits)
    {
      (*o_octets)= 2;
      break;
    }

    l_bits= (i_octet >> 4);

    if (0xe /* 1110b */ == l_bits)
    {
      (*o_octets)= 3;
      break;
    }

    l_bits= (i_octet >> 3);

    if (0x1e /* 11110b */ == l_bits)
    {
      (*o_octets)= 4;
      break;
    }

    l_bits= (i_octet >> 2);

    if (0x3e /* 111110b */ == l_bits)
    {
      (*o_octets)= 5;
      break;
    }

    l_bits= (i_octet >> 1);

    if (0x7e /* 1111110b  */ == l_bits)
    {
      (*o_octets)= 6;
      break;
    }

    l_valid= 0;
    (*o_octets)= 1;

  }while(0);

  if (o_valid)
  {
    (*o_valid)= l_valid;
  }

  return;
}
