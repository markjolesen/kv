/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_utf8_test.h"

static void
read_file(
  unsigned char**                       o_buf,
  size_t*                               o_size,
  char const*                           i_path,
  size_t const                          i_pad)
{
  unsigned char*                        l_buf;
  FILE*                                 l_fp;
  size_t                                l_size;

  *o_buf= 0;
  *o_size= 0;

  do
  {

    l_fp= fopen(i_path,  "rb");

    if (0 == l_fp)
    {
      break;
    }

    fseek(l_fp, 0, SEEK_END);
    l_size= (size_t)ftell(l_fp);
    fseek(l_fp, 0, SEEK_SET);

    *o_size= (i_pad + l_size);

    l_buf= (unsigned char*)malloc((*o_size));
    memset(l_buf, 0, (*o_size));
    fread(l_buf, 1, l_size, l_fp);
    fclose(l_fp);
    *o_buf= l_buf;

  }while(0);

  return;
}

#define TEST_FILE "../test_files/UTF-8-demo.txt"

extern void
abc_utf8c_parse_test()
{
  unsigned char*                        l_buf;
  unsigned char*                        l_copy;
  unsigned char*                        l_dst;
  size_t                                l_left;
  size_t                                l_size;
  unsigned char*                        l_src;
  struct abc_utf8c                      l_utf8c;

  read_file(&l_buf, &l_size, TEST_FILE, 4);

  if (0 == l_buf)
  {
    return;
  }

  l_src= l_buf;
  l_copy= (unsigned char*)malloc(l_size);
  memset(l_copy, -1, l_size);
  l_dst= l_copy;
  l_left= l_size;
  
  do
  {

    l_size= l_left;

    abc_utf8c_parse(&l_utf8c, (void**)&l_src, &l_left);

    if (0 == l_utf8c.m_count)
    {
      if (0 != l_left)
      {
        printf("%s(%d): 0 != %ld\n", __FUNCTION__, __LINE__, l_left);
      }
      break;
    }

    if (((ptrdiff_t)l_src == (ptrdiff_t)l_buf) || (l_size <= l_left))
    {
      printf("%s(%d): not advancing\n", __FUNCTION__, __LINE__);
      break;
    }

    if (0 == l_utf8c.m_valid)
    {
      printf("%s(%d): invalid char\n", __FUNCTION__, __LINE__);
    }

    memcpy(l_dst, &l_utf8c.m_block[0], l_utf8c.m_count);
    l_dst+= l_utf8c.m_count;

  }while(1);

  l_dst= l_copy;
  l_src= l_buf;
  l_left= 0;

  do
  {

    if (l_size <= l_left)
    {
      break;
    }

    if ((*l_dst) != (*l_src))
    {
      printf("%s(%d): [%ld] 0x%02x != 0x%02X\n",  __FUNCTION__, __LINE__, l_left, (*l_dst), (*l_src));
    }

    l_dst++;
    l_src++;
    l_left++;

  }while(1);

  free(l_copy);
  free(l_buf);

  return;
}
