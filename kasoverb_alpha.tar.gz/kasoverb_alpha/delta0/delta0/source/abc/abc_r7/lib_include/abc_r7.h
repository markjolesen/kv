/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2007, 2010, 2011 Dante University Foundation and Contributors
  
  Redir7ibution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redir7ibutions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redir7ibutions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the dir7ibution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#ifndef __abc_r7_h__

#include <stddef.h>
#include <string.h>
#include <stdlib.h>

typedef enum
{
  abc_r7_nul                            =0x00, /* '\0' null char */
  abc_r7_soh                            =0x01, /* start of header */
  abc_r7_stx                            =0x02, /* start of text */
  abc_r7_etx                            =0x03, /* end of text */
  abc_r7_eot                            =0x04, /* end of transmission */
  abc_r7_enq                            =0x05, /* enquiry */
  abc_r7_ack                            =0x06, /* acknowledgment */
  abc_r7_bel                            =0x07, /* bell */
  abc_r7_bs                             =0x08, /* backspace */
  abc_r7_ht                             =0x09, /* horizontal tab */
  abc_r7_lf                             =0x0a, /* line feed */
  abc_r7_vt                             =0x0b, /* vertical tab */
  abc_r7_ff                             =0x0c, /* form feed */
  abc_r7_cr                             =0x0d, /* carriage return */
  abc_r7_so                             =0x0e, /* shift out */
  abc_r7_si                             =0x0f, /* shift in */
  abc_r7_dle                            =0x10, /* data link escape */
  abc_r7_dc1                            =0x11, /* xon     (device control 1) */
  abc_r7_dc2                            =0x12, /* device control 2 */
  abc_r7_dc3                            =0x13, /* xoff     (device control 3) */
  abc_r7_dc4                            =0x14, /* device control 4 */
  abc_r7_nak                            =0x15, /* negative acknowledgement */
  abc_r7_syn                            =0x16, /* synchronous idle */
  abc_r7_etb                            =0x17, /* end of trans. block */
  abc_r7_can                            =0x18, /* cancel */
  abc_r7_em                             =0x19, /* end of medium */
  abc_r7_sub                            =0x1a, /* substitute */
  abc_r7_esc                            =0x1b, /* escape */
  abc_r7_fs                             =0x1c, /* file separator */
  abc_r7_gs                             =0x1d, /* group separator */
  abc_r7_rs                             =0x1e, /* request to send/record separator */
  abc_r7_us                             =0x1f, /* unit separator */
  abc_r7_space                          =0x20, /* ' ' space */
  abc_r7_exclamation                    =0x21, /* '!' exclamation mark */
  abc_r7_qoute                          =0x22, /* '"' double quote */
  abc_r7_hash                           =0x23, /* '#' number sign */
  abc_r7_dollar                         =0x24, /* '$' dollar sign */
  abc_r7_pct                            =0x25, /* '%' percent */
  abc_r7_ampersand                      =0x26, /* '&' ampersand */
  abc_r7_squote                         =0x27, /* '\'' single quote */
  abc_r7_lparen                         =0x28, /* '(' left/opening parenthesis */
  abc_r7_rparen                         =0x29, /* ')' right/closing parenthesis) */
  abc_r7_asterisk                       =0x2a, /* '*' asterisk */
  abc_r7_plus                           =0x2b, /* '+' plus */
  abc_r7_comma                          =0x2c, /* ',' comma */
  abc_r7_minus                          =0x2d, /* '-' minus or dash */
  abc_r7_period                         =0x2e, /* '.' dot */
  abc_r7_slash                          =0x2f, /* '/' forward slash */
  abc_r7_0                              =0x30, /* '0' number zero */
  abc_r7_1                              =0x31,
  abc_r7_2                              =0x32,
  abc_r7_3                              =0x33,
  abc_r7_4                              =0x34,
  abc_r7_5                              =0x35,
  abc_r7_6                              =0x36,
  abc_r7_7                              =0x37,
  abc_r7_8                              =0x38,
  abc_r7_9                              =0x39,
  abc_r7_colon                          =0x3a, /* colon */
  abc_r7_semicolon                      =0x3b, /* semi-colon */
  abc_r7_lessthan                       =0x3c, /* less than */
  abc_r7_equal                          =0x3d, /* equal sign */
  abc_r7_greaterthan                    =0x3e, /* greater than */
  abc_r7_question                       =0x3f, /* question mark */
  abc_r7_at                             =0x40, /* at symbol */
  abc_r7_upr_A                          =0x41,
  abc_r7_upr_B                          =0x42,
  abc_r7_upr_C                          =0x43,
  abc_r7_upr_D                          =0x44,
  abc_r7_upr_E                          =0x45,
  abc_r7_upr_F                          =0x46,
  abc_r7_upr_G                          =0x47,
  abc_r7_upr_H                          =0x48,
  abc_r7_upr_I                          =0x49,
  abc_r7_upr_J                          =0x4a,
  abc_r7_upr_K                          =0x4b,
  abc_r7_upr_L                          =0x4c,
  abc_r7_upr_M                          =0x4d,
  abc_r7_upr_N                          =0x4e,
  abc_r7_upr_O                          =0x4f,
  abc_r7_upr_P                          =0x50,
  abc_r7_upr_Q                          =0x51,
  abc_r7_upr_R                          =0x52,
  abc_r7_upr_S                          =0x53,
  abc_r7_upr_T                          =0x54,
  abc_r7_upr_U                          =0x55,
  abc_r7_upr_V                          =0x56,
  abc_r7_upr_W                          =0x57,
  abc_r7_upr_X                          =0x58,
  abc_r7_upr_Y                          =0x59,
  abc_r7_upr_Z                          =0x5a,
  abc_r7_lbracket                       =0x5b, /* left/opening bracket */
  abc_r7_backslash                      =0x5c, /* back slash */
  abc_r7_rbracket                       =0x5d, /* right/closing bracket */
  abc_r7_caret                          =0x5e, /* caret/circumflex */
  abc_r7_underscore                     =0x5f, /* underscore */
  abc_r7_TICK                           =0x60, /* '`' */
  abc_r7_lwr_a                          =0x61,
  abc_r7_lwr_b                          =0x62,
  abc_r7_lwr_c                          =0x63,
  abc_r7_lwr_d                          =0x64,
  abc_r7_lwr_e                          =0x65,
  abc_r7_lwr_f                          =0x66,
  abc_r7_lwr_g                          =0x67,
  abc_r7_lwr_h                          =0x68,
  abc_r7_lwr_i                          =0x69,
  abc_r7_lwr_j                          =0x6a,
  abc_r7_lwr_k                          =0x6b,
  abc_r7_lwr_l                          =0x6c,
  abc_r7_lwr_m                          =0x6d,
  abc_r7_lwr_n                          =0x6e,
  abc_r7_lwr_o                          =0x6f,
  abc_r7_lwr_p                          =0x70,
  abc_r7_lwr_q                          =0x71,
  abc_r7_lwr_r                          =0x72,
  abc_r7_lwr_s                          =0x73,
  abc_r7_lwr_t                          =0x74,
  abc_r7_lwr_u                          =0x75,
  abc_r7_lwr_v                          =0x76,
  abc_r7_lwr_w                          =0x77,
  abc_r7_lwr_x                          =0x78,
  abc_r7_lwr_y                          =0x79,
  abc_r7_lwr_z                          =0x7a,
  abc_r7_lbrace                         =0x7b, /* left/opening brace */
  abc_r7_pipe                           =0x7c, /* pipe/vertical bar */
  abc_r7_rbrace                         =0x7d, /* right/closing brace */
  abc_r7_tilde                          =0x7e,
  abc_r7_del                            =0x7f /* delete */
} abc_r7_t;

enum abc_r7_filter_action
{
  abc_r7_filter_action_leave,
  abc_r7_filter_action_remove,
  abc_r7_filter_action_replace,
  abc_r7_filter_action_terminate
};


#ifdef __cplusplus
extern "C" {
#endif

typedef void 
(*abc_r7_filter_t)(
  enum abc_r7_filter_action*const       o_action,
  char*const                            o_template,
  char const                            i_octet);

extern void
abc_r7_filter(
  void*                                 io_block,
  size_t const                          i_size,
  abc_r7_filter_t const                 i_filter);

extern void
abc_r7_filter_default(
  enum abc_r7_filter_action*const       o_action,
  char*const                            o_template,
  char const                            i_octet);

extern void
abc_r7_shift_left(
  void*const                            io_block,
  size_t const                          i_size,
  size_t const                          i_slot,
  size_t const                          i_count,
  char const                            i_template);

extern void
abc_r7_shift_right(
  void*const                            io_block,
  size_t const                          i_size,
  size_t const                          i_slot,
  size_t const                          i_count,
  char const                            i_template);

#ifdef __cplusplus
}
#endif

#define __abc_r7_h__
#endif

