/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_csv_test.h"


#define raw_cell_slots 4

extern void
abc_csv_cell_read_test()
{
static char const                       l_raw[]=
{
"\"\"\r\r\r\n"
",\n"
"\0\1\2\3\4,"
"\"í®í¿¿,\1,,,,,,\n"
"\"コンニチハ,"
"\"a\""
};
static struct
{
  char const*                           m_text;
  enum abc_csv_term                     m_terminator;
  size_t                                m_size;
}                                       l_result[]=
{
  {"", abc_csv_term_eol, 0},
  {"", abc_csv_term_sep, 0},
  {"", abc_csv_term_eol, 0},
  {"\0\1\2\3\4", abc_csv_term_sep, 5},
  {"í®í¿¿,\1,,,,,,\nコンニチハ", abc_csv_term_sep, (sizeof("í®í¿¿,\1,,,,,,\nコンニチハ") -1)},
  {"a", abc_csv_term_eof, 2}
};
  char*                                 l_block;
  ptrdiff_t                             l_exit;
  int                                   l_rc;
  struct abc_utf8_sfb                   l_sfb;
  size_t                                l_size;
  size_t                                l_slot;
  struct abc_array                      l_array;
  enum abc_csv_term                     l_terminator;

  abc_array_assign(&l_array);
  abc_array_set_object_size(&l_array, 1);
  abc_array_set_step(&l_array, 256);

  do
  {

    memset(&l_sfb, 0, sizeof(l_sfb));
    l_sfb.m_block= (void*)&l_raw[0];
    l_sfb.m_size= sizeof(l_raw);
    l_slot= 0;

    do
    {

      l_exit= abc_csv_cell_read(
        &l_terminator,
        &l_array,
        abc_utf8_sfb_fread,
        &l_sfb);

      if (l_exit)
      {
        break;
      }

      abc_array_get_count(&l_size, &l_array);
      abc_array_as_ptr(&l_block, &l_array);

      if (l_result[l_slot].m_size == l_size)
      {
        if (l_size)
        {
          l_rc= memcmp(l_result[l_slot].m_text, l_block, l_size);
          if (l_rc)
          {
            printf("%s(%d): %ld\n", __FUNCTION__, __LINE__, l_slot);
          }
        }
      }
      else
      {
          printf("%s(%d): %ld\n", __FUNCTION__, __LINE__, l_slot);
      }

      if (l_terminator != l_result[l_slot].m_terminator)
      {
        printf("%s(%d): %ld\n", __FUNCTION__, __LINE__, l_slot);
      }

      if (abc_csv_term_eof == l_terminator)
      {
        break;
      }

      l_slot++;

    }while(1);

    if (5 != l_slot)
    {
      printf("%s(%d): %d != %ld\n", __FUNCTION__, __LINE__, 5, l_slot);
    }

  }while(0);

  abc_array_discharge(&l_array);

  return;
}
