/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap
*/
/*
  Copyright (c) 2007, 2010-2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_csv.h"

extern int
abc_csv_cell_read(
  enum abc_csv_term*const               o_terminator,
  struct abc_array*const                io_array,
  abc_utf8c_read_t const                i_read,
  abc_utf8c_handle_t const              i_handle)
{
  int                                   l_exit;
  int                                   l_in_escape;
  char                                  l_octet;
  enum abc_csv_term                     l_terminator;
  struct abc_utf8c                      l_utf8c;
  struct abc_utf8c                      l_utf8c_peek;

  l_terminator= abc_csv_term_eof;
  l_exit= 0;

  do
  {

    if (0 == io_array)
    {
      break;
    }

    abc_string_set_count(io_array, 0);

    if (0 == i_read)
    {
      break;
    }

    l_in_escape= 0;
    memset(&l_utf8c_peek, 0, sizeof(l_utf8c_peek));

    do
    {

      if (0 == l_utf8c_peek.m_count)
      {
        l_exit= abc_utf8c_read(&l_utf8c, i_read, i_handle);
      }
      else
      {
        memcpy(&l_utf8c, &l_utf8c_peek, sizeof(l_utf8c));
        memset(&l_utf8c_peek, 0, sizeof(l_utf8c_peek));
        l_exit= 0;
      }

      if (l_exit)
      {
        l_terminator= abc_csv_term_bad;
        break;
      }

      if (0 == l_utf8c.m_count)
      {
        l_terminator= abc_csv_term_eof;
        break;
      }

      if (1 == l_utf8c.m_count)
      {
        l_octet= l_utf8c.m_block[0];

        if (0 == l_in_escape)
        {
          if (abc_r7_cr == l_octet)
          {
            continue;
          }

          if (abc_r7_lf == l_octet)
          {
            l_terminator= abc_csv_term_eol;
            break;
          }

          if (abc_r7_comma == l_octet)
          {
            l_terminator= abc_csv_term_sep;
            break;
          }

          if (abc_r7_qoute == l_octet)
          {
            l_in_escape= 1;
            continue;
          }
        } 
        else if (abc_r7_qoute == l_octet)
        {
          l_exit= abc_utf8c_read(&l_utf8c_peek, i_read, i_handle);

          if (l_exit)
          {
            l_terminator= abc_csv_term_bad;
            break; 
          }
          
          if ((1 == l_utf8c_peek.m_count) && 
            (abc_r7_qoute == l_utf8c_peek.m_block[0]))
          {
            memset(&l_utf8c_peek, 0, sizeof(l_utf8c_peek));
          }
          else
          {
            l_in_escape= 0;
            continue;
          }
        } 
      } 

      abc_string_append(io_array, l_utf8c.m_block, l_utf8c.m_count);

    }while(1);

  }while(0);

  if (o_terminator)
  {
    (*o_terminator)= l_terminator;
  }

  return l_exit;
}
