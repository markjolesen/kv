/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2007, 2010 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#ifndef __abc_array_h__

#include <stddef.h>
#include <string.h>
#include <stdlib.h>

#include "abc_blob.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void
(*abc_array_foreach_t)(
  void*const                            io_object,
  void*                                 i_user,
  int*const                             io_continue);

typedef void 
(*abc_array_assign_t)(
  void*const                            o_object,
  int*const                             o_discharge,
  size_t const                          i_slot);

typedef void 
(*abc_array_discharge_t)(
  void*const                            io_object);

typedef void
(*abc_array_compare_t)(
  int*const                             o_result,
  void const*const                      i_obj_to_compare,
  void const*const                      i_obj_to_find);

struct abc_array_method
{
  abc_array_assign_t                    m_assign;
  abc_array_discharge_t                 m_discharge;
};

struct abc_array
{
  struct abc_blob                       m_blob;
  size_t                                m_object_size;
  size_t                                m_count;
  size_t                                m_step;
  struct abc_array_method               m_method;
};

extern void
abc_array_as_ptr(
  char**const                           o_object,
  struct abc_array const*const          i_array);

extern void
abc_array_assign(
  struct abc_array*const                o_array);

extern void
abc_array_assign_object(
  int*                                  o_removed,
  struct abc_array*const                io_array,
  size_t                                i_slot,
  int const                             i_discharge,
  void const*const                      i_template);

extern void
abc_array_decrease_object_size(
  struct abc_array*const                io_array,
  size_t const                          i_amount);

extern void
abc_array_decrement(
  struct abc_array*const                io_array,
  size_t const                          i_count);

extern void
abc_array_discharge(
  struct abc_array*const                io_array);

extern void
abc_array_foreach(
  struct abc_array*const                io_array,
  size_t const                          i_slot,
  size_t const                          i_count,
  abc_array_foreach_t const             i_callback,
  void*                                 i_user);

extern void
abc_array_get_count(
  size_t*const                          o_count,
  struct abc_array const*const          i_array);

extern void
abc_array_get_object_size(
  size_t*const                          o_size,
  struct abc_array const*const          i_array);

extern void
abc_array_get_step(
  size_t*const                          o_step,
  struct abc_array const*const          i_array);

extern void
abc_array_increase_object_size(
  struct abc_array*const                io_array,
  size_t const                          i_amount);

extern void
abc_array_increment(
  struct abc_array*const                io_array,
  size_t const                          i_count,
  void const*const                      i_template);

extern void
abc_array_insert(
  struct abc_array*const                io_array,
  size_t const                          i_slot,
  size_t const                          i_count,
  void const*const                      i_template);

extern void
abc_array_lookup_binary(
  int*const                             o_found,
  size_t*const                          o_slot,
  struct abc_array const*const          io_array,
  abc_array_compare_t const             i_compare,
  void const*const                      i_user);

extern void
abc_array_lookup_linear(
  int*const                             o_found,
  size_t*const                          o_slot,
  struct abc_array const*const          io_array,
  abc_array_compare_t const             i_compare,
  void const*const                      i_user);

extern void
abc_array_remove(
  struct abc_array*const                io_array,
  size_t const                          i_slot,
  size_t const                          i_count); 

extern void
abc_array_reset(
  struct abc_array*const                io_array,
  size_t const                          i_slot,
  size_t const                          i_count,
  int const                             i_discharge,
  void const*const                      i_template);

extern void
abc_array_set_count(
  struct abc_array*const                io_array,
  size_t const                          i_count,
  void const*const                      i_template);

extern void
abc_array_set_method(
  struct abc_array*const                io_array,
  abc_array_assign_t const              i_assign,
  abc_array_discharge_t const           i_remove);

extern void
abc_array_set_object_size(
  struct abc_array*const                io_array,
  size_t const                          i_size);

extern void
abc_array_set_step(
  struct abc_array*const                io_array,
  size_t const                          i_step);

extern void
abc_array_shift_left(
  struct abc_array*const                io_array,
  size_t                                i_slot,
  size_t                                i_count,
  void const*const                      i_template);

extern void
abc_array_shift_right(
  struct abc_array*const                io_array,
  size_t                                i_slot,
  size_t                                i_count,
  void const*const                      i_template);


#ifdef __cplusplus
}
#endif

#define __abc_array_h__
#endif
