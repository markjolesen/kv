/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2007, 2010 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_array.h"

#include <stdio.h> /* remove */

extern void
abc_blob_set_size(
  struct abc_blob*const                 io_blob,
  size_t const                          i_size)
{
  void*                                 l_block;
  size_t                                l_delta;

  do
  {

    if (0 == io_blob)
    {
      break;
    }

    if (0 > (ptrdiff_t)i_size)
    {
      break;
    }

    if (i_size <= (*io_blob).m_size)
    {
      l_delta= ((*io_blob).m_size - i_size);
      if (l_delta)
      {
        l_block= (((char*)(*io_blob).m_block) + i_size);
        memset(l_block, 0, l_delta);
      }
      (*io_blob).m_size= i_size;
      break;
    }

    if (i_size <= (*io_blob).m_alloc)
    {
      (*io_blob).m_size= i_size;
      break;
    }

    if (0 > (ptrdiff_t)i_size)
    {
      break;
    }

    if (0 == (*io_blob).m_alloc)
    {
      l_block= malloc(i_size);

      if (0 == l_block)
      {
        break;
      }

      memset(l_block, 0, i_size);
    
      (*io_blob).m_block= l_block;
      (*io_blob).m_alloc= i_size;
      (*io_blob).m_size= i_size;

      break;
    }

    l_block= realloc((*io_blob).m_block, i_size);
  
    if (0 == l_block)
    {
      break;
    }

    (*io_blob).m_block= l_block;

    l_block= ((char*)l_block + (*io_blob).m_size);
    l_delta= (i_size - (*io_blob).m_size);
    memset(l_block, 0, l_delta);

    (*io_blob).m_alloc= i_size;
    (*io_blob).m_size= i_size;

  }while(0);

  return;
}
