/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2007, 2010-2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_array.h"

extern void
abc_array_increase_object_size(
  struct abc_array*const                io_array,
  size_t const                          i_amount)
{
  size_t                                l_blob_size;
  char*                                 l_head;
  char*                                 l_object;
  size_t                                l_blob_size_prev;
  size_t                                l_object_size;
  size_t                                l_object_size_prev;
  size_t                                l_slot;
  char*                                 l_tail;

  do
  {

    if (0 == io_array)
    {
      break;
    }

    if (0 == i_amount)
    {
      break;
    }

    if ((ptrdiff_t)0 > (ptrdiff_t)((*io_array).m_object_size + i_amount))
    {
      break;
    }

    l_blob_size_prev= (*io_array).m_blob.m_size;
    l_object_size_prev= (*io_array).m_object_size;
    l_object_size= ((*io_array).m_object_size + i_amount);
    l_blob_size= ((*io_array).m_count * l_object_size);
    abc_blob_set_size(&(*io_array).m_blob, l_blob_size);

    if (l_blob_size != (*io_array).m_blob.m_size)
    {
      break;
    }

    (*io_array).m_object_size= l_object_size;

    if (0 == (*io_array).m_count)
    {
      break;
    }

    l_object= (char*)(*io_array).m_blob.m_block;
    l_head= (l_object + l_blob_size_prev);
    l_tail= (l_object + (*io_array).m_blob.m_size);
    l_slot= (*io_array).m_count;

    do
    {

      if (1 >= l_slot)
      {
        break;
      }

      l_head-= l_object_size_prev;
      l_tail-= l_object_size;

      memcpy(l_tail, l_head, l_object_size_prev); 
      memset(l_head, 0, l_object_size_prev);

      l_slot--;

    }while(1);

  }while(0);

  return;
}
