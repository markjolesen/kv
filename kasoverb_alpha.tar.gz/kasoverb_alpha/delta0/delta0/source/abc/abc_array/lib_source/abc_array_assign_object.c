/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of library abc
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "abc_array.h"

extern void
abc_array_assign_object(
  int*                                  o_removed,
  struct abc_array*const                io_array,
  size_t                                i_slot,
  int const                             i_discharge,
  void const*const                      i_template)
{
  void*                                 l_object;
  size_t                                l_offset;
  int                                   l_remove;

  l_remove= 0;

  do
  {

    if (0 == io_array)
    {
      break;
    }

    if (i_slot >= (*io_array).m_count)
    {
      break;
    }

    l_offset= (i_slot * (*io_array).m_object_size);
    l_object= (char*)(*io_array).m_blob.m_block + l_offset;

    if (i_discharge && (*io_array).m_method.m_discharge)
    {
      (*(*io_array).m_method.m_discharge)(l_object);
    }

    if (0 == i_template)
    {
      memset(l_object, 0, (*io_array).m_object_size);
    }
    else
    {
      memcpy(l_object, i_template, (*io_array).m_object_size);
    }

    if ((*io_array).m_method.m_assign)
    {
      l_remove= 0;
      (*(*io_array).m_method.m_assign)(l_object, &l_remove, i_slot);
      if (l_remove)
      {
        abc_array_remove(io_array, i_slot, 1);
      }
    }

  }while(0);

  if (o_removed)
  {
    (*o_removed)= l_remove;
  }

  return;
}
