/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2008-2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#if !defined(__kvc_icon_hxx__)

#include <FL/Fl_Pixmap.H>

class kvc_icon
{
public:

static Fl_Pixmap&
kvc_icon_application_view_columns();

static Fl_Pixmap&
kvc_icon_get_database();

static Fl_Pixmap&
kvc_icon_get_database_table();

static Fl_Pixmap&
kvc_icon_get_find();

static Fl_Pixmap&
kvc_icon_get_resultset_first();

static Fl_Pixmap&
kvc_icon_get_resultset_last();

static Fl_Pixmap&
kvc_icon_get_resultset_next();

static Fl_Pixmap&
kvc_icon_get_resultset_previous();

static Fl_Pixmap&
kvc_icon_get_style();

static Fl_Pixmap&
kvc_icon_get_table_relationship();

private:

  static Fl_Pixmap                      m_application_view_columns;
  static Fl_Pixmap                      m_database;
  static Fl_Pixmap                      m_database_table;
  static Fl_Pixmap                      m_find;
  static Fl_Pixmap                      m_resultset_first;
  static Fl_Pixmap                      m_resultset_last;
  static Fl_Pixmap                      m_resultset_next;
  static Fl_Pixmap                      m_resultset_previous;
  static Fl_Pixmap                      m_style;
  static Fl_Pixmap                      m_table_relationship;

kvc_icon();

~kvc_icon();

kvc_icon(
  kvc_icon const&);

kvc_icon&
operator=(
  kvc_icon const&);

};

inline Fl_Pixmap&
kvc_icon::kvc_icon_application_view_columns()
{
  return m_application_view_columns;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_database()
{
  return m_database;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_database_table()
{
  return m_database_table;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_find()
{
  return m_find;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_resultset_first()
{
  return m_resultset_first;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_resultset_last()
{
  return m_resultset_last;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_resultset_next()
{
  return m_resultset_next;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_resultset_previous()
{
  return m_resultset_previous;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_style()
{
  return m_style;
}

inline Fl_Pixmap&
kvc_icon::kvc_icon_get_table_relationship()
{
  return m_table_relationship;
}

#define __kvc_icon_hxx__
#endif
