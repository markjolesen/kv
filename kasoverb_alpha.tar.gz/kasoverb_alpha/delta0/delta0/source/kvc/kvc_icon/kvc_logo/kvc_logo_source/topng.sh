#!/bin/sh

./kasoverb_logo_create.pl

gm convert kasoverb_logo_1024x1024.svg	kasoverb_logo_1024x1024.png
gm convert kasoverb_logo_128x128.svg	kasoverb_logo_128x128.png
gm convert kasoverb_logo_16x16.svg		kasoverb_logo_16x16.png
gm convert kasoverb_logo_2048x2048.svg	kasoverb_logo_2048x2048.png
gm convert kasoverb_logo_256x256.svg	kasoverb_logo_256x256.png
gm convert kasoverb_logo_32x32.svg		kasoverb_logo_32x32.png
gm convert kasoverb_logo_512x512.svg	kasoverb_logo_512x512.png
gm convert kasoverb_logo_64x64.svg		kasoverb_logo_64x64.png
gm convert kasoverb_logo_8x8.svg		kasoverb_logo_8x8.png
