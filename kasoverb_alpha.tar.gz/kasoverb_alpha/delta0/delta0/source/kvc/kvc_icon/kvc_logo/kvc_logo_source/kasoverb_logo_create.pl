#!/usr/bin/perl 
#  Copyright (c) 2011 Dante University Foundation and Contributors
#  
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are met:
#  
#     1. Redistributions of source code must retain the above copyright notice,
#        this list of conditions and the following disclaimer.
#  
#     2. Redistributions in binary form must reproduce the above copyright
#        notice, this list of conditions and the following disclaimer in the
#        documentation and/or other materials provided with the distribution.
#  
#  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
#  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
#  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
#  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
#  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
#  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
#  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
#  POSSIBILITY OF SUCH DAMAGE.
#  
#  The views and conclusions contained in the software and documentation are
#  those of the authors and should not be interpreted as representing official
#  policies, either expressed or implied, of Dante University Foundation.
#  
#  This file is part of library abc
#  
#  Dante University Foundation
#  P.O. Box 812158
#  Wellesley, MA 02482
#  USA
#  www.danteuniversity.org

# Purpose: The KasoVerb logo is algorithmically created. This Perl script, generates the 
# KaoVerb logo in SVG format, in various sizes. (SVG supposedly scales, however, 
# the output of this algorithm, scales in proportion to the dimensions 


$d= 8; # width of box
$s= 1; # stroke width


$last= 1024;

  do
  {
    $f= "./kasoverb_logo_${d}x${d}.svg";

    open FH, ">$f" or die "$! --- unable to create `$f'";

    modus_operandi();

    if ($last < $d)
    {
      exit;
    }

    close FH;

    $d*= 2;
    $s*= 2;

  } while(1);

sub modus_operandi()
{


  $t= ($d / 2) - $s; # top

  print FH  <<TEXT;
  <svg width='${d}px' height='${d}px' viewBox='0 0 $d $d'>
  <!-- top -->
  <line x1='0' y1='$t' x2='$d' y2='$t' style='stroke-width:$s; stroke: black;'/>

TEXT

  $x0= ($d / 2) + $s;

  print FH  <<TEXT;
  <!-- slant to left -->
  <line x1='$x0' y1='$t' x2='0' y2='$d' style='stroke-width:$s; stroke: black;'/>

TEXT

  $x0= ($d / 2) - $s;

  print FH  <<TEXT;
  <!-- slant to right -->
  <line x1='$x0' y1='$t' x2='$d' y2='$d' style='stroke-width:$s; stroke: black;'/>

TEXT

  print FH  <<TEXT;
  <!-- peg left -->
  <line x1='0' y1='$t' x2='0' y2='$d' style='stroke-width:$s; stroke: black;'/>

  <!-- peg right -->
  <line x1='$d' y1='$t' x2='$d' y2='$d' style='stroke-width:$s; stroke: black;'/>

TEXT

  # $x0= int(sqrt($d))
  $x0= ($d / 5); 
  $y0= $d - $x0;

  print FH  <<TEXT;
  <!-- peg left middle -->
  <line x1='$x0' y1='$t' x2='$x0' y2='$y0' style='stroke-width:$s; stroke: black;'/>

TEXT

  $x0= ($d - $x0);

  print FH  <<TEXT;
  <!-- peg right middle -->
  <line x1='$x0' y1='$t' x2='$x0' y2='$y0' style='stroke-width:$s; stroke: black;'/>

TEXT


  print FH  "</svg>\n";

}

=END

vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
