/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#ifndef __kvc_sheet_hxx__

#include <FL/Enumerations.H>
#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Scrollbar.H>
#include <FL/Fl_Scrollbar.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Menu_Item.H>

#include "abc_say.h"
#include "abc_xywh_int.h"
#include "kvc_db.h"
#include "kvc_common.hxx"

class kvc_sheet:
  public Fl_Double_Window
{
public:

#if 0
  static size_t const                   m_frame_edge_len= 2;
  static int const                      m_min_resize_len= 2;
#endif

kvc_sheet();

virtual
~kvc_sheet();

void
configure();

virtual void
draw();

void
draw_header();

void
draw_grid();

void
draw_cell(
  struct kvc_db_grid_node const*const   i_node,
  struct abc_xywh_int const*const       i_box,
  size_t                                i_row,
  size_t                                i_col);

virtual int 
handle(
  int                                   i_event);

static void
kvc_sheet_scroll_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

virtual void
resize(
  int const                             i_x_pos,
  int const                             i_y_pos,
  int const                             i_x_len,
  int const                             i_y_len);

void
load(
  struct kvc_db_grid *const             i_grid);

protected:

  Fl_Scrollbar                          m_scroll_x;
  struct kvc_db_grid*                   m_db_grid;
  struct
  {
    abc_xywh_int                        m_box;
    struct kvc_db_grid_node *           m_node;
    size_t                              m_cell; 
    size_t                              m_row;
    int                                 m_dragging;
  }                                     m_event;

void
scroll_resize();

void
scroll_configure();

private:

void
handle_find_cell(
  int *const                            o_found);

void
handle_push_cell();

kvc_sheet(
  int const                             i_x_len,
  int const                             i_y_len,
  char const*                           i_label= 0);

kvc_sheet(
  kvc_sheet const&);

kvc_sheet&
operator=(
  kvc_sheet const&);

kvc_sheet(
  int const                             i_x_pos,
  int const                             i_y_pos,
  int const                             i_x_len,
  int const                             i_y_len,
  char const*                           i_label= 0);

};

inline void
kvc_sheet::load(
  struct kvc_db_grid *const             i_grid)
{
  m_db_grid= i_grid;
  configure();
  damage(FL_DAMAGE_ALL);
  return;
}

#define __kvc_sheet_hxx__
#endif
