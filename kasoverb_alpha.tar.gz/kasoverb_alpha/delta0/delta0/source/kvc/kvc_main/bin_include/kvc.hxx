/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#ifndef __kvc_hxx__

#include <stddef.h>
#include <stdlib.h>

#include <FL/Fl.H>
#include <FL/Enumerations.H>
#include <FL/filename.H>
#include <FL/fl_utf8.h>
#include <FL/Fl_Widget.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Check_Browser.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Menu_Button.H>
#include <FL/Fl_Menu_Item.H>
#include <FL/Fl_Native_File_Chooser.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Return_Button.H>
#include <FL/fl_message.H>
#include <FL/Fl_Pack.H>
#include <FL/Fl_Scroll.H>
#include <FL/Fl_Menu_.H>
#include <FL/Fl_Menu_Button.H>

#include "abc_array.h"
#include "abc_xywh_int.h"
#include "abc_say.h"
#include "abc_r8.h"
#include "abc_r7.h"

#include "kvc_icon.hxx"
#include "kvc_db.h"

#include "kvc_sheet.hxx"
#include "kvc_common.hxx"
#include "kvc_alt.hxx"
#include "kvc_search.hxx"

#ifndef CHANGE_DOS_FILE_SEP_SWITCH
# if defined(WIN32) || defined(__EMX__) && !defined(__CYGWIN__)
#   define CHANGE_DOS_FILE_SEP_SWITCH
# endif
#endif


class kvc:
  public Fl_Double_Window
{
public:

enum db_read_type
{
  DB_READ_FIRST,
  DB_READ_NEXT,
  DB_READ_PREV,
  DB_READ_LAST
};

kvc();

virtual
~kvc();

void
db_closeall();

void
db_disconnect();

int
db_open(
    char const*                         i_path);

void
db_read(
  enum db_read_type const               i_type);

void
db_read_alt(
  char const*                           i_lang,
  char const*                           i_inf); 

void
db_read_record(
  size_t const                          i_record);

void
kvc_search_show();

void
db_toggle(
  char const*                           i_lang,
  int                                   i_is_on);

void
table_load();

virtual void
resize(
  int const                             i_x_pos,
  int const                             i_y_pos,
  int const                             i_x_len,
  int const                             i_y_len);

void
sync();

protected:


  /* toolbar */
  kvc_sheet                             m_sheet;
  Fl_End                                m_end1;
  Fl_Group                              m_tb; 
  Fl_Button                             m_dbopen;
  Fl_Menu_Button                        m_table;
  Fl_Button                             m_first;
  Fl_Button                             m_next;
  Fl_Button                             m_prev;
  Fl_Button                             m_last;
  Fl_Button                             m_lookup;
  Fl_End                                m_end2;
  kvc_alt                               m_alt;
  Fl_End                                m_end3;

  kvc_search                            m_search;

  kvc_db_grid                           m_db_grid;

private:

kvc(
  int const                             i_x_len,
  int const                             i_y_len,
  char const*                           i_label= 0);

kvc(
  kvc const&);

kvc&
operator=(
  kvc const&);

kvc(
  int const                             i_x_pos,
  int const                             i_y_pos,
  int const                             i_x_len,
  int const                             i_y_len,
  char const*                           i_label= 0);

static void
kvc_alt_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_closeall_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_dbopen_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_disconnect_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_first_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_last_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_lookup_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_next_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_prev_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_search_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
kvc_table_toggle_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

};

inline void
kvc::sync()
{
  m_sheet.redraw();
  m_alt.load(&m_db_grid);
  m_alt.redraw();
}

#define __kvc_hxx__
#endif
