/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#ifndef __kvc_search_hxx__

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <FL/Enumerations.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Return_Button.H>
#include <FL/Fl_Hold_Browser.H>
#include <FL/Fl_Widget.H>
#include <FL/Fl_Input.H>
#include <FL/filename.H>
#include <FL/fl_utf8.h>

#include "abc_say.h"
#include "abc_array.h"

#include "kvc_dict.h"
#include "kvc_db.h"

class kvc_search :
  public  Fl_Double_Window
{
public:

kvc_search(
  char const*                           i_label);

virtual 
~kvc_search();

void
add_all();

void
add_filtered();

void
attach(
  struct kvc_db_grid *                  i_grid);

void
db_read_record(
  size_t const                          i_record);

void
clear();

void
sync();

protected:

  Fl_Hold_Browser                       m_browser;
  Fl_Input                              m_filter;
  Fl_Button                             m_close;

  struct kvc_db_grid *                  m_db_grid;

private:

kvc_search();

kvc_search(
  kvc_search const&);

kvc_search(
  int const                             i_x_pos,
  int const                             i_y_pos,
  int const                             i_x_len,
  int const                             i_y_len,
  char const*                           i_label= 0);

static void
close_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
filter_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
search_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

static void
browser_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user);

};

inline void
kvc_search::db_read_record(
  size_t const                          i_record)
{
  kvc_db_grid_read(m_db_grid, i_record);
}

inline void
kvc_search::clear()
{
  m_browser.clear();
}

#define __kvc_search_hxx__
#endif
