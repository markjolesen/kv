/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "kvc.hxx"

void
kvc::kvc_dbopen_cb(
  Fl_Widget*                            i_widget,
  void*                                 i_user)
{
  Fl_Native_File_Chooser                l_browser;
  char const*                           l_filename;
  char*                                 l_head;
  kvc*                                  l_kvc;
  char*                                 l_path;
  char const*                           l_path_part;
  int                                   l_rc;
  char*                                 l_tail;

  l_path= 0;
  l_kvc= reinterpret_cast<kvc*>(i_user);

  do
  {
    l_browser.title("open database");
    l_browser.type(Fl_Native_File_Chooser::BROWSE_FILE);
    l_browser.options(Fl_Native_File_Chooser::NO_OPTIONS);
    l_browser.filter("KVC\t*.kvc");

    l_rc= l_browser.show();

    if (l_rc)
    {
      break;
    }

    l_filename= l_browser.filename();

    if (0 == l_filename)
    {
      break;
    }

    abc_r8s_ditto(&l_path, l_filename);

    if (0 == l_path)
    {
      break;
    }
  
    l_head= 0;
    l_tail= l_path;

    do
    {

      if (0 == (*l_tail))
      {
        break;
      }

#if defined(CHANGE_DOS_FILE_SEP_SWITCH)
      if (abc_r7_backslash == (*l_tail))
      {
        *l_tail= abc_r7_slash;
      }
#endif

      if (abc_r7_slash == (*l_tail))
      {
        l_head= l_tail;
      }

      l_tail++;

    }while(1);

    if (0 == l_head)
    {
      l_path_part= 0;
    }
    else
    {
      *l_head++= 0;
      l_path_part= l_path;

      l_tail= strrchr(l_head, abc_r7_period);

      if (l_tail)
      {
        (*l_tail)= 0;
      }
    }

    (*l_kvc).db_open(l_path_part);
  
  }while(0);

  if (l_path)
  {
    free(l_path);
    l_path= 0;
  }

  return;
}

