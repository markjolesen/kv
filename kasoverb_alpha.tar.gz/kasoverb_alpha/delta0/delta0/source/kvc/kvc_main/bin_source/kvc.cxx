/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "kvc.hxx"

kvc::kvc() :
  Fl_Double_Window(win_x_len, win_y_len, abc_say("Kaso Verb Conjugation System")),
  m_sheet(),
  m_end1(),
  m_tb(x(),y(),w(),tool_y_len),
  m_dbopen(0,0,0,0),
  m_table(0, 0, 0, 0),
  m_first(0, 0, 0, 0),
  m_next(0, 0, 0, 0),
  m_prev(0, 0, 0, 0),
  m_last(0, 0, 0, 0),
  m_lookup(0, 0, 0, 0),
  m_end2(),
  m_alt(),
  m_end3(),
  m_search(abc_say("Explorer")),
  m_db_grid()
{
  int                                   l_x_len;
  int                                   l_x_pos;
  int                                   l_y_len;
  int                                   l_y_pos;


  size_range(w(),h());
  color(FL_BACKGROUND2_COLOR);

  m_tb.color(FL_BACKGROUND_COLOR);
  m_tb.box(FL_BORDER_BOX);
  m_tb.resizable(0); 

  m_dbopen.tooltip(abc_say("open database"));
  m_dbopen.image(kvc_icon::kvc_icon_get_database());
  l_x_pos= m_tb.x() + sides_len;
  l_y_pos= m_tb.y() + sides_len;
  l_x_len= btn_x_len;
  l_y_len= btn_y_len;
  m_dbopen.resize(l_x_pos, l_y_pos, l_x_len, l_y_len);
  m_dbopen.callback(kvc_dbopen_cb, this);

  m_table.deactivate();
  m_table.align(FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  m_table.tooltip(abc_say("open/close tables"));
  m_table.image(kvc_icon::kvc_icon_get_database_table());
  l_x_pos+= 8+m_dbopen.w();
  l_x_len= (2 * btn_x_len);
  m_table.resize(l_x_pos, l_y_pos, l_x_len, l_y_len);

  m_first.deactivate();
  m_first.tooltip(abc_say("first"));
  m_first.image(kvc_icon::kvc_icon_get_resultset_first());
  l_x_pos+= 8+(btn_x_len + m_dbopen.w());
  l_x_len= btn_x_len;
  m_first.resize(l_x_pos, l_y_pos, l_x_len, l_y_len);
  m_first.callback(kvc_first_cb, this);

  m_next.deactivate();
  m_next.tooltip(abc_say("next"));
  m_next.image(kvc_icon::kvc_icon_get_resultset_next());
  l_x_pos+= m_first.w();
  m_next.resize(l_x_pos, l_y_pos, l_x_len, l_y_len);
  m_next.callback(kvc_next_cb, this);

  m_prev.deactivate();
  m_prev.tooltip(abc_say("previous"));
  m_prev.image(kvc_icon::kvc_icon_get_resultset_previous());
  l_x_pos+= m_next.w();
  m_prev.resize(l_x_pos, l_y_pos, l_x_len, l_y_len);
  m_prev.callback(kvc_prev_cb, this);

  m_last.deactivate();
  m_last.tooltip(abc_say("last"));
  m_last.image(kvc_icon::kvc_icon_get_resultset_last());
  l_x_pos+= m_prev.w();
  m_last.resize(l_x_pos, l_y_pos, l_x_len, l_y_len);
  m_last.callback(kvc_last_cb, this);

  m_lookup.deactivate();
  m_lookup.tooltip(abc_say("explorer"));
  m_lookup.image(kvc_icon::kvc_icon_get_find());
  l_x_pos+= (btn_x_len + m_last.w());
  l_x_len= btn_x_len;
  m_lookup.resize(l_x_pos, l_y_pos, l_x_len, l_y_len);
  m_lookup.callback(kvc_lookup_cb, this);

  kvc_db_grid_assign(&m_db_grid);

  m_alt.clear();
  m_alt.showroot(0);
  m_alt.when(FL_WHEN_RELEASE);
  m_alt.callback(kvc_alt_cb, this);

  m_search.hide();
  m_search.callback(kvc_search_cb, this);

  return;
}


kvc::~kvc()
{
  kvc_db_grid_discharge(&m_db_grid);

  return;
}

