/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "kvc_sheet.hxx"

void
kvc_sheet::handle_push_cell()
{
  kvc_rec_anchor*                       l_anchor;
  kvc_rec_anchor_bit const*             l_bit;
  int                                   l_hit;
  Fl_Menu_Item*                         l_item;
  Fl_Menu_Item                          l_menu[(1+kvc_rec_anchor_bit_max)];
  Fl_Menu_Item const*                   l_picked;
  size_t                                l_slot;

  do
  {

    if ((0 == m_db_grid) || (0 == (*m_db_grid).m_extent_x))
    {
      break;
    }

    l_anchor= &(*m_event.m_node).m_rec.\
      m_switch[m_event.m_row][m_event.m_cell].m_anchor;

    if (1 >= (*l_anchor).m_count)
    {
      break;
    }

    l_hit= Fl::event_inside(
      (*l_anchor).m_bbox.m_x_pos,
      (*l_anchor).m_bbox.m_y_pos,
      (*l_anchor).m_bbox.m_x_len, 
      (*l_anchor).m_bbox.m_y_len);

    if (0 == l_hit)
    {
      break;
    }

    l_slot= 0;
    memset(&l_menu, 0, sizeof(l_menu));
    l_item= &l_menu[0];
    l_bit= &(*l_anchor).m_bit[0];

    do
    {

      if ((*l_anchor).m_count <= l_slot)
      {
        break;
      }

      (*l_item).text= (*l_bit).m_text;
      (*l_item).user_data_= reinterpret_cast<void*>(l_slot);

      l_slot++;
      l_item++;
      l_bit++;

    }while(1);

    l_picked= l_menu[0].pulldown(
      (*l_anchor).m_bbox.m_x_pos,
      (*l_anchor).m_bbox.m_y_pos,
      0,
      0,
      &l_menu[(*l_anchor).m_slot]);

    if (0 == l_picked)
    {
      break;
    }

    l_slot= reinterpret_cast<size_t>((*l_picked).user_data_);

    if ((*l_anchor).m_slot == l_slot)
    {
      break;
    }

    (*l_anchor).m_slot= l_slot;

    redraw();

  }while(0);

  return;
}
