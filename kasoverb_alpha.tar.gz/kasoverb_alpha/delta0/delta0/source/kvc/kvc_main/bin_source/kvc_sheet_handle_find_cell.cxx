/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "kvc_sheet.hxx"

void
kvc_sheet::handle_find_cell(
  int *const                            o_found)
{
  abc_xywh_int                          l_box;
  size_t                                l_cell;
  int                                   l_edge;
  int                                   l_hit;
  struct kvc_db_grid_node *             l_node;
  size_t                                l_row;

  memset(&m_event, 0, sizeof(m_event));
  l_row= 0;
  l_box.m_x_pos= edge_len;
  l_box.m_x_pos-= m_scroll_x.value();
  l_box.m_y_pos= edge_len;
  l_box.m_x_len= 0;
  l_box.m_y_len= 30;

  do
  {

    if ((0 == m_db_grid) || (0 == (*m_db_grid).m_extent_x))
    {
      break;
    }

    do
    {

      if (kvc_dict_grid_row_count_used <= l_row)
      {
        break;
      }

      l_box.m_x_pos= edge_len;
      l_box.m_x_pos-= m_scroll_x.value();
      l_box.m_x_len= 0;
      l_cell= 0;

      do
      {
        if (kvc_dict_row_cell_count_used <= l_cell)
        {
          break;
        }

        l_node= (*m_db_grid).m_head;

        do
        {
          if ((0 == l_node) || (*l_node).m_prop.m_is_disabled)
          {
            break;
          }

          if (0 == (*l_node).m_prop.m_col[l_cell].m_is_hidden)
          {

            l_box.m_x_len= (*l_node).m_prop.m_col[l_cell].m_x_len;
            l_edge= (l_box.m_x_pos + l_box.m_x_len);

            if (w() < l_box.m_x_pos)
            {
              l_cell= kvc_dict_row_cell_count_used;
              break;
            }

            if (edge_len < l_edge)
            {

              l_hit= Fl::event_inside(
                l_box.m_x_pos,
                l_box.m_y_pos,
                l_box.m_x_len,
                l_box.m_y_len);

              if (l_hit)
              {
                *o_found= 1;
                m_event.m_node= l_node;
                m_event.m_row= l_row;
                m_event.m_cell= l_cell;
                m_event.m_box= l_box;
                m_event.m_dragging= 0;
                return;

              }

            }

            l_box.m_x_pos+= l_box.m_x_len;
          }

          l_node= (*l_node).m_next;

        }while(1);

        l_cell++;

      }while(1);

      l_box.m_y_pos+=30;
      l_row++;

    }while(1);

  }while(0);

  return;
}

