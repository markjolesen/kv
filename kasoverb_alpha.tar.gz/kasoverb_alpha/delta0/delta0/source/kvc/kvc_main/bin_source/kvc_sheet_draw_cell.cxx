/*
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "kvc_sheet.hxx"

void
kvc_sheet::draw_cell(
  kvc_db_grid_node const*const          i_node,
  abc_xywh_int const*const              i_box,
  size_t                                i_row,
  size_t                                i_col)
{
  abc_xywh_int*                         l_bbox;
  kvc_dict_cell_str_t                   l_block;
  abc_xywh_int                          l_box;
  abc_xywh_int                          l_btn;
  int                                   l_height;
  size_t                                l_slot;
  char const*                           l_src;
  kvc_rec_switch const*                 l_switch;
  kvc_rec_switch const*                 l_switch_alt;
  char*                                 l_tail;
  int                                   l_width;


  do
  {

    if (0 == i_node)
    {
      break;
    }

    memset(l_block, 0, sizeof(l_block));
    l_tail= l_block;

    memcpy(&l_box, i_box, sizeof(l_box));
    l_box.m_x_pos+= 2;
    l_box.m_x_len-= 2;

    l_switch= &(*i_node).m_rec.m_switch[i_row][i_col];
    l_slot= 0;
    l_src= 0;

    do
    {
      if ((*l_switch).m_count <= l_slot)
      {
        break;
      }

      if (kvc_rec_switch_bit_text == (*l_switch).m_bit[l_slot].m_type)
      {
        l_src= (*l_switch).m_bit[l_slot].m_ref.m_text;
      }
      else if (kvc_rec_switch_bit_slot == (*l_switch).m_bit[l_slot].m_type)
      {
        l_switch_alt= &(*i_node).m_rec.m_switch[i_row][(*l_switch).m_bit[l_slot].m_ref.m_slot];
        l_src= (*l_switch_alt).m_anchor.m_bit[(*l_switch_alt).m_anchor.m_slot].m_text;
      }
      else if (kvc_rec_switch_bit_anchor == (*l_switch).m_bit[l_slot].m_type) 
      {
        do
        {
          if (l_block[0])
          {
            fl_measure(l_block, l_width, l_height, 0);
            fl_color(FL_FOREGROUND_COLOR);
            fl_draw(l_block,
              l_box.m_x_pos,
              l_box.m_y_pos,
              l_box.m_x_len,
              l_box.m_y_len,
              FL_ALIGN_LEFT);
            l_box.m_x_pos+= l_width;
            memset(l_block, 0, sizeof(l_block));
            l_tail= &l_block[0];
          }
          l_src= (*l_switch).m_anchor.m_bit[(*l_switch).m_anchor.m_slot].m_text;
          l_bbox= (abc_xywh_int*)&(*l_switch).m_anchor.m_bbox;
          memset(l_bbox, 0, sizeof(*l_bbox));
          if ((0 == l_src) || (0 == l_src[0]))
          {
            break;
          }
          if (1 >= (*l_switch).m_anchor.m_count)
          {
            break;
          }
          fl_measure(l_src, l_width, l_height, 0);
          (*l_bbox).m_x_pos= l_box.m_x_pos;
          (*l_bbox).m_y_pos= (2 + (*i_box).m_y_pos);
          (*l_bbox).m_y_len= (*i_box).m_y_len;
          if (1 & (*l_bbox).m_y_len)
          {
            (*l_bbox).m_y_len--;
          }
          (*l_bbox).m_x_len= (4 + l_width + (*l_bbox).m_y_len);
          if (1 & (*l_bbox).m_x_len)
          {
            (*l_bbox).m_x_len++;
          }
          (*l_bbox).m_y_len-= 4;
          fl_draw_box(
            FL_DOWN_BOX,
            (*l_bbox).m_x_pos,
            (*l_bbox).m_y_pos,
            (*l_bbox).m_x_len,
            (*l_bbox).m_y_len,
            FL_BACKGROUND_COLOR);
          l_btn.m_x_pos= (((*l_bbox).m_x_pos + (*l_bbox).m_x_len) - (*l_bbox).m_y_len);
          l_btn.m_y_pos= (*l_bbox).m_y_pos + 2;
          l_btn.m_x_len= (*l_bbox).m_y_len - 2;
          l_btn.m_y_len= (*l_bbox).m_y_len - 4;
          fl_draw_box(
              FL_UP_BOX,
              l_btn.m_x_pos,
              l_btn.m_y_pos,
              l_btn.m_x_len,
              l_btn.m_y_len,
              FL_BACKGROUND_COLOR);
          fl_color(FL_FOREGROUND_COLOR);
          fl_draw(
            l_src,
            (2+(*l_bbox).m_x_pos),
            (*l_bbox).m_y_pos,
            ((*l_bbox).m_x_len-(*l_bbox).m_x_len),
            (*l_bbox).m_y_len,
            FL_ALIGN_LEFT);
          l_btn.m_x_pos+=3;
          l_btn.m_x_len-=7;
          l_btn.m_y_len= ((*l_bbox).m_y_len / 3);
          l_btn.m_y_pos= (*l_bbox).m_y_pos + l_btn.m_y_len;
          fl_polygon(
            l_btn.m_x_pos+2,
            l_btn.m_y_pos,
            l_btn.m_x_pos + l_btn.m_x_len -2,
            l_btn.m_y_pos,
            l_btn.m_x_pos + (l_btn.m_x_len/2),
            l_btn.m_y_pos + l_btn.m_y_len);
          l_box.m_x_pos+= (l_width/strlen(l_src)) + (*l_bbox).m_x_len;
          l_src= 0;
        }while(0);
      }
      do
      {
        if (0 == l_src)
        {
          break;
        }
        do
        {
          if (0 == (*l_src))
          {
            break;
          }
          *l_tail++= *l_src++;
        }while(1);
        *l_tail++= abc_r7_space;
      }while(0);
      l_slot++;
    }while(1);

    if (&l_block[0] != l_tail)
    {

      if (&l_block[0] < l_tail)
      {
        l_tail--;
      }

      *l_tail= 0;
    }

    if (l_block[0])
    {
      fl_color(FL_FOREGROUND_COLOR);
      fl_draw(l_block,
        l_box.m_x_pos,
        l_box.m_y_pos,
        l_box.m_x_len,
        l_box.m_y_len,
        FL_ALIGN_LEFT);
    }

  }while(0);

  return;
}

