/* 
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap:ruler
*/
/*
  Copyright (c) 2008-2011 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#if !defined(__kvc_rec_switch_h__)

#include <errno.h>
#include <stddef.h>

#include "abc_r7.h"
#include "kvc_dict.h"

#include "kvc_rec_anchor.h"

enum
{
  kvc_rec_switch_bit_max                = 32,
  kvc_rec_switch_slot_open              = abc_r7_lbracket,
  kvc_rec_switch_slot_close             = abc_r7_rbracket
};

typedef enum
{
  kvc_rec_switch_bit_anchor             = -1, /**< kvc_rec_switch_bit.m_ref.m_slot refers to the anchor slot */
  kvc_rec_switch_bit_text               = 0, /**< kvc_rec_switch_bit.m_ref.m_text points to text */
  kvc_rec_switch_bit_slot               = 1 /**< kvc_rec_switch_bit.m_ref.m_slot refers to switch slot containing text (non-circular) */
} kvc_rec_switch_bit_t;

struct kvc_rec_switch_bit
{
  kvc_rec_switch_bit_t                  m_type;
  union
  {
    char const*                         m_text;
    size_t                              m_slot;
  }                                     m_ref;
};

struct kvc_rec_switch
{
  struct kvc_rec_switch_bit             m_bit[kvc_rec_switch_bit_max];
  size_t                                m_count;
  struct kvc_rec_anchor                 m_anchor;
};

#ifdef DEBUG
void
kvc_rec_switch_bit_dump(
  FILE*                                 i_fp,
  struct kvc_rec_switch_bit const*const i_bit);
#endif

#ifdef DEBUG
void
kvc_rec_switch_dump(
  FILE*                                 i_fp,
  struct kvc_rec_switch const*const     io_switch);
#endif

void
kvc_rec_switch_set(
  struct kvc_rec_switch*const           o_switch,
  char*                                 io_text);

void
kvc_rec_switch_append_bit_anchor(
  struct kvc_rec_switch*const           io_switch);

void
kvc_rec_switch_append_bit_text(
  struct kvc_rec_switch*const           io_switch,
  char*                                 io_text);

void
kvc_rec_switch_append_bit_slot(
  struct kvc_rec_switch*const           io_switch,
  char**                                io_text);

void
kvc_rec_switch_bit_as_str(
  char const**const                     o_str,
  kvc_rec_switch_bit_t                  i_type);

void
kvc_rec_switch_strchr(
  char **const                          io_str,
  char const                            i_find);

#define __kvc_rec_switch_h__
#endif
