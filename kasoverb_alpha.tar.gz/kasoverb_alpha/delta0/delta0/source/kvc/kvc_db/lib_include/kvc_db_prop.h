/* 
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap 
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#ifndef __kvc_db_prop_h__

#include <FL/Enumerations.H>

#include "kvc_dict.h"

#define kvc_db_prop_x_len_default       135
#define kvc_db_prop_x_max_len           300
#define kvc_prop_vendor                 "kasoverb.org"

struct kvc_db_prop
{
  size_t                                m_is_disabled:1;
  struct
  {
    int                                 m_is_hidden;
    size_t                              m_x_len;
  }                                     m_col[kvc_dict_row_cell_count_used];
  struct
  {
    Fl_Color                            m_header;
    Fl_Color                            m_column;
  }                                     m_color;
};

extern void
kvc_db_prop_assign(
  struct kvc_db_prop *const             i_prop);

extern void
kvc_db_prop_load(
  struct kvc_db_prop *const             io_prop,
  char const*                           i_path,
  char const*                           i_name);

extern void
kvc_db_prop_discharge(
  struct kvc_db_prop *const             i_prop);

extern void
kvc_db_prop_save(
  struct kvc_db_prop *const             i_prop,
  char const*                           i_path,
  char const*                           i_name);

#define __kvc_db_prop_h__
#endif  
