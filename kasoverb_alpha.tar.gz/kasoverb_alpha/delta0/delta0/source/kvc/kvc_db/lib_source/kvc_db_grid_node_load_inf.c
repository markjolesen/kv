/* 
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap 
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "kvc_db.h"

extern kvc_db_exit_t
kvc_db_grid_node_load_inf(
  struct kvc_db_grid_node*const         io_node,
  struct kvc_db_method const*const      i_method,
  char const*                           i_path)
{
  struct kvc_dict_cell*                 l_cell;
  size_t                                l_count;
  kvc_db_exit_t                         l_exit;
  FILE*                                 l_handle;
  char*                                 l_path;
  size_t                                l_rc;

  l_exit= kvc_db_exit_state;
  l_handle= 0;
  l_path= 0;

  do
  {

    if (0 == io_node) 
    {
      break;
    }

    if (0 == (*io_node).m_handle)
    {
      break;
    }

    kvc_db_path_create(&l_path, i_path, (*io_node).m_name, kvc_db_suffix_inf);

    if (0 == l_path)
    {
      break;
    }

    if (0 == (*i_method).m_open)
    {
      l_handle= fopen(l_path, "rb");
    }
    else
    {
      l_handle= (*(*i_method).m_open)(l_path, "rb");
    }

    if (0 == l_handle)
    {
      l_exit= kvc_db_exit_error;
      break;
    }

    l_exit= kvc_db_io_get_filesize(&l_count, l_handle);

    if (l_exit)
    {
      break;
    }

    l_count/= sizeof(struct kvc_dict_cell);

    if (l_count != (*io_node).m_count)
    {
      l_exit= kvc_db_exit_error;
      break;
    }

    abc_array_set_count(&(*io_node).m_inf, l_count, 0);
    abc_array_as_ptr((char**)&l_cell, &(*io_node).m_inf);

    l_rc= fseek(l_handle, 0, SEEK_SET);

    if (l_rc)
    {
      l_exit= kvc_db_exit_error;
      break;
    }

    l_count= fread(
      (void*)l_cell,
      sizeof(struct kvc_dict_cell),
      l_count,
      l_handle);

    if (l_count != (*io_node).m_count)
    {
      l_exit= kvc_db_exit_error;
      break;
    }

    l_rc= 0;

    do
    {
      if (l_rc  == l_count)
      {
        break;
      }
     

      kvc_dict_cell_set_internal(l_cell);

      l_cell++;
      l_rc++;

    }while(1);

  }while(0);

  if (l_handle)
  {
    fclose(l_handle);
  }

  if (l_path)
  {
    free(l_path);
  }

  return l_exit;
}
