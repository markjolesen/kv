/* 
vim:expandtab:softtabstop=2:tabstop=2:shiftwidth=2:nowrap 
*/
/*
  Copyright (c) 2014 Dante University Foundation and Contributors
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:
  
     1. Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer.
  
     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY Dante University Foundation ``AS IS'' AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL Dante University Foundation OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
  The views and conclusions contained in the software and documentation are
  those of the authors and should not be interpreted as representing official
  policies, either expressed or implied, of Dante University Foundation.
  
  This file is part of Kaso Verb Conjugation (KVC) System 
  
  Dante University Foundation
  P.O. Box 812158
  Wellesley, MA 02482
  USA
  www.danteuniversity.org
*/
#include "kvc_db.h"


extern kvc_db_exit_t
kvc_db_xref_open(
  struct kvc_db_xref *const             io_xref,
  struct kvc_db_method const*const      i_method,
  char const*                           i_path,
  char const*                           i_lang)
{
  int                                   l_count;
  FILE*                                 l_handle;
  dirent **                             l_dirent;
  kvc_db_exit_t                         l_exit;
  struct kvc_db_xref_node *             l_node;
  char*                                 l_path;
  char*                                 l_ptr;
  int                                   l_rc;
  size_t                                l_slot;

  l_exit= kvc_db_exit_ok;
  l_path= 0;
  l_handle= 0;

  do
  {

    if (0 == io_xref)
    {
      break;
    }

    l_count= fl_filename_list(i_path, &l_dirent);

    if (0 >= l_count)
    {
      break;
    }

    l_slot= 0;

    do
    {

      if (l_count <= l_slot)
      {
        break;
      }

      do
      {

        if (abc_r7_period == (*l_dirent[l_slot]).d_name[0])
        {
          break;
        }

        l_ptr= strrchr((*l_dirent[l_slot]).d_name, abc_r7_period);

        if (0 == l_ptr)
        {
          break;
        }

        *l_ptr= 0;
        l_ptr++;

        l_rc= strcmp(i_lang, (*l_dirent[l_slot]).d_name);

        if (l_rc)
        {
          break;
        }

        l_rc= strcmp(l_ptr, kvc_db_suffix_grid);

        if (0 == l_rc)
        {
          break;
        }

        l_rc= strcmp(l_ptr, kvc_db_suffix_inf);

        if (0 == l_rc)
        {
          break;
        }

        l_rc= strcmp(l_ptr, kvc_db_suffix_prefs);

        if (0 == l_rc)
        {
          break;
        }

        kvc_db_path_create(&l_path, i_path, i_lang, l_ptr);

        if (0 == l_path)
        {
          l_exit= kvc_db_exit_error;
          break;
        }

        if (0 == (*i_method).m_open)
        {
          l_handle= fopen(l_path, "rb");
        }
        else
        {
          l_handle= (*i_method).m_open(l_path, "rb");
        }

        if (0 == l_handle)
        {
          l_exit= kvc_db_exit_error;
          break;
        }

        l_node= (struct kvc_db_xref_node*)malloc(sizeof(*l_node));

        if (0 == l_node)
        {
          l_exit= kvc_db_exit_error;
          break;
        }

        memset(l_node, 0, sizeof(*l_node));
        
        abc_r8s_ditto(&(*l_node).m_name, l_ptr);
  
        if (0 == (*l_node).m_name)
        {
          l_exit= kvc_db_exit_error;
          break;
        }
        
        if (0 == (*io_xref).m_head)
        {
          (*io_xref).m_head= l_node;
          (*io_xref).m_tail= l_node;
        }
        else
        {
          (*io_xref).m_tail->m_next= l_node;
          (*io_xref).m_tail= l_node;
        }

        (*l_node).m_handle= l_handle; 
        l_handle= 0;
        l_node= 0;

      }while(0);

      if (l_exit)
      {
        break;
      }

      if (l_path)
      {
        free(l_path);
        l_path= 0;
      }

      l_slot++;

    }while(1);
    
    fl_filename_free_list(&l_dirent, l_count);

  }while(0);

  if (l_handle)
  {
    fclose(l_handle);
  }

  if (l_path)
  {
    free(l_path);
    l_path= 0;
  }

  return l_exit;
}
